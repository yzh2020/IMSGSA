% ��Ӧ�Ⱥ���
function fit=Ptest_functions(L,F_index,dim)

% ��Ӧ�Ⱥ���Sphere
if F_index==1
    fit=sum((L).^2);
end
% ��Ӧ�Ⱥ���Schwefel 2.22
if F_index==2 
    fit=sum(abs(L))+prod(abs(L));
end
% ��Ӧ�Ⱥ���Schwefel 1.2
if F_index==3
    dim=size(L,2);
    fit=0;
    for i=1:dim
        fit=fit+sum(L(1:i))^2;
    end
end
% ��Ӧ�Ⱥ���Schwefel 2.21
if F_index==4
    fit=max(abs(L));
end
% ��Ӧ�Ⱥ���Zakharov
if F_index==5
    fit=sum(L.^2)+(sum([1:dim].*(L)/2)).^2+(sum([1:dim].*(L)/2)).^4;%%%%5
%     dim=size(L,2);fit=sum(100*(L(2:dim)-(L(1:dim-1).^2)).^2+(L(1:dim-1)-1).^2);
end
% ��Ӧ�Ⱥ���Step
if F_index==6
    fit=sum(abs((L+.5)).^2);
end
% ��Ӧ�Ⱥ���Quartic
if F_index==7
    dim=size(L,2);
    fit=sum([1:dim].*(L.^4))+rand;
end
% ��Ӧ�Ⱥ���Rosenbrock
if F_index==8
    dim=size(L,2);
    fit=sum(100*(L(2:dim)-(L(1:dim-1).^2)).^2+(L(1:dim-1)-1).^2);
%     fit=sum(-L.*sin(sqrt(abs(L))));
end
% ��Ӧ�Ⱥ���Rastrigin
if F_index==9
    dim=size(L,2);
    fit=sum(L.^2-10*cos(2*pi.*L))+10*dim;
end
% ��Ӧ�Ⱥ���Ackley
if F_index==10
    dim=size(L,2);
    fit=-20*exp(-.2*sqrt(sum(L.^2)/dim))-exp(sum(cos(2*pi.*L))/dim)+20+exp(1);
end
% ��Ӧ�Ⱥ���Griewank
if F_index==11
    dim=size(L,2);
    fit=sum(L.^2)/4000-prod(cos(L./sqrt([1:dim])))+1;
end
% ��Ӧ�Ⱥ���Penalized1
if F_index==12
    dim=size(L,2);
    fit=(pi/dim)*(10*((sin(pi*(1+(L(1)+1)/4)))^2)+sum((((L(1:dim-1)+1)./4).^2).*...
   (1+10.*((sin(pi.*(1+(L(2:dim)+1)./4)))).^2))+((L(dim)+1)/4)^2)+sum(Ufun(L,10,100,4));
end
% ��Ӧ�Ⱥ���Penalized2
if F_index==13
    dim=size(L,2);
    fit=.1*((sin(3*pi*L(1)))^2+sum((L(1:dim-1)-1).^2.*(1+(sin(3.*pi.*L(2:dim))).^2))+...
    ((L(dim)-1)^2)*(1+(sin(2*pi*L(dim)))^2))+sum(Ufun(L,5,100,4));
end
% ��Ӧ�Ⱥ���Schwefel 2.26
if F_index==14
    fit=sum(-L.*sin(sqrt(abs(L))));
%     fit=sum(L.^2)+(sum([1:dim].*(L)/2)).^2+(sum([1:dim].*(L)/2)).^4;%%%%10
end
% ��Ӧ�Ⱥ���Salomon
if F_index==15
    fit=1-cos(2*pi*sqrt(sum(L.^2)))+0.1*sum(L.^2);
end
% ��Ӧ�Ⱥ���Alpine
if F_index==16
    fit=sum(abs(L.*sin(L)+0.1.*L));
end
% ��Ӧ�Ⱥ���Schaffer 7
if F_index==17
    fit=0;
    for i=1:dim-1
        fit=fit+(L(i).^2+L(i+1).^2).^0.25+((L(i).^2+L(i+1).^2).^0.25)*((sin(50*((L(i).^2+L(i+1).^2).^0.1))).^2);
    end
    fit=fit/(dim-1);
end
% ��Ӧ�Ⱥ���Expansion 10
if F_index==18
    fit=0;
    for i=1:dim-1
        fit=fit+evaluatePublic2(L(i),L(i+1));
    end
    fit=fit+evaluatePublic2(L(dim),L(1));
end
% ��Ӧ�Ⱥ���Levy
if F_index==19
   dim=size(L,2);
   for i=1:dim
       w(i)=1+(L(i)-1)/4;
   end
   term1=(sin(pi*w(1))).^2;
   term3=((w(dim)-1).^2)*(1+sin(2*pi*w(dim)).^2);
   sumo=0;
   for ii=1:(dim-1)
       wi=w(ii);
       new=(wi-1).^2*(1+10*(sin(pi*wi+1)^2));
       sumo=sumo+new;
   end
   fit=sumo+term1+term3;
end
% ��Ӧ�Ⱥ���Powell
if F_index==20
    dim=size(L,2);
    sumo=0;
    for i=1:dim/4
        term1=(L(4*i-3)+10*L(4*i-2)).^2;
        term2=5*(L(4*i-1)-L(4*i)).^2;
        term3=(L(4*i-2)-2*L(4*i-1)).^4;
        term4=10*(L(4*i-3)-L(4*i)).^2;
        sumo=sumo+term1+term2+term3+term4;
    end
    fit=sumo;
end
% ��Ӧ�Ⱥ���Dixon-Price
if F_index==21
    dim=size(L,2);
    term1=(L(1)-1).^2;
    sumo=0;
    for i=2:dim
        term2=i*((2*(L(i)).^2-L(i)-1).^2);
        sumo=sumo+term2;
    end
    fit=sumo+term1;
end
% ��Ӧ�Ⱥ���Weierstrass
if F_index==22
    Kmax=20;
    dim=size(L,2);
    sumo1=0;
    for j=1:dim
        term1=0;
        for i=0:Kmax
            term1=term1+(0.5.^i)*cos(2*pi*(3.^i)*(L(j)+0.5));
        end
        sumo1=sumo1+term1;
    end
    term2=0;
    for i=0:Kmax
        term2=term2+(0.5.^i)*cos(2*pi*(3.^i)*0.5);
    end
    term2=(term2)*dim;
    fit=sumo1-term2;
end
% ��Ӧ�Ⱥ���Schaffer
if F_index==23
    term1=(sin(sqrt(sum(L.^2)))).^2-0.5;
    term2=(1+0.001*(sqrt(sum(L.^2)))).^2;
    sumo=0.5+term1/term2;
    fit=sumo;
end

% ��Ӧ�Ⱥ���Masters
if F_index==24
    dim=size(L,2);
    sumo=0;
    for i=1:(dim-1)
        term0=L(i).^2+L(i+1).^2+0.5*(L(i).^2)*(L(i+1).^2);
        term1=exp(-term0/8);
        term2=cos(4*sqrt(term0));
        sumo=sumo+term1*term2;
    end
    fit=-sumo+dim-1;
end

% ��Ӧ�Ⱥ���12-13����
function fit=Ufun(x,a,k,m)
   fit=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
% ��Ӧ�Ⱥ���18����
function   fit=evaluatePublic2(X,Y)
   fit=((X.^2+Y.^2).^0.25)*(sin(50*(X.^2+Y.^2).^0.1).^2+1);   
   
