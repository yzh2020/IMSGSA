 %%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
 %%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
function [X]= IMSLOBL(X,t,Max_iter,ub,lb,F_index,Type)
[N,dim]=size(X);
for i=1:N
    Flag4ub=X(i,:)>ub; % check if they exceed (up) the boundaries
    Flag4lb=X(i,:)<lb;% check if they exceed (down) the boundaries
    X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    fitnesP=PevaluateF(X(i,:),F_index,Type);
    %%LOBL strategy
    k=(1+(t/Max_iter)^0.5)^10;
    Xnew = (ub+lb)/2+(ub+lb)/(2*k)-X(i,:)/k;
    %update positions
    flag4ub = Xnew>ub;
    flag4lb = Xnew<lb;
    Xnew = (Xnew.*(~(flag4ub+flag4ub)))+lb.*flag4lb+ub.*flag4ub;
    if(PevaluateF(Xnew,F_index,Type)<fitnesP)
       X(i,:) = Xnew;
    end 
end
 %%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
 %%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn

