%%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
function [X,fitness] = IMSSSAOperation(i,X,worseX,fitness,ub,lb,F_index,Type)
    newX=randn(1)*exp((worseX-X)/(i)^2);
    newX=Pspace_bound(newX,ub,lb);
    newfit=PevaluateF(newX,F_index,Type);
    if newfit< fitness
         fitness = newfit;
         X=newX;
    end
end
%%%%%%%%%%%%%%西安交大大学-杨中华-2023.01.01-yangzhonghua@stu.xjtu.edu.cn