 %%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
 %%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
%%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 10�� ����ӳ������ѡ��1-10�ֱ�Ϊ��tent��Logistic��Cubic��chebyshev��Piecewise��sinusoidal��Sine,ICMIC, Circle,Bernoulli
function result = IMSchaos(index, N, dim)

switch index
    case 1
        % tent ӳ��
        tent=1.1;  %tent����ϵ��
        Tent=rand(N,dim);
        for i=1:N
            for j=2:dim
                if Tent(i,j-1)<tent
                    Tent(i,j)=Tent(i,j-1)/tent;
                elseif Tent(i,j-1)>=tent
                    Tent(i,j)=(1-Tent(i,j-1))/(1-tent);
                end
            end
        end
        result = Tent;
        
    case 2
        % Logistic ӳ��
        miu=2;  %����ϵ��
        Logistic=rand(N,dim);
        for i=1:N
            for j=2:dim
                Logistic(i,j)=miu.* Logistic(i,j-1).*(1-Logistic(i,j-1));
            end
        end
        result = Logistic;
        
    case 3
        % Cubic ӳ��
        cubic=2.595;
        Cubic=rand(N,dim);
        for i=1:N
            for j=2:dim
                Cubic(i,j)=cubic.*Cubic(i,j-1).*(1-Cubic(i,j-1).^2);
            end
        end
        result = Cubic;
        
    case 4
        %chebyshev ӳ��
        chebyshev=4;
        Chebyshev=rand(N,dim);
        for i=1:N
            for j=2:dim
                Chebyshev(i,j)=cos(chebyshev.*acos(Chebyshev(i,j-1)));
            end
        end
        result = Chebyshev;
        
    case 5
        %Piecewise  ӳ��
        p=1;
        Piecewise=rand(N,dim);
        for i=1:N
            for j=2:dim
                if Piecewise(i,j-1)>0&&Piecewise(i,j-1)<p
                    Piecewise(i,j)=Piecewise(i,j-1)/p;
                elseif Piecewise(i,j-1)>=p&&Piecewise(i,j-1)<0.5
                    Piecewise(i,j)=(Piecewise(i,j-1)-p)/(0.5-p);
                elseif Piecewise(i,j-1)>=0.5&&Piecewise(i,j-1)<1-p
                    Piecewise(i,j)=(1-p-Piecewise(i,j-1))/(0.5-p);
                elseif Piecewise(i,j-1)>=1-p&&Piecewise(i,j-1)<1
                    Piecewise(i,j)=(1-Piecewise(i,j-1))/p;
                end
            end
        end
        result = Piecewise;
        
        
    case 6
        %sinusoidal ӳ��
        sinusoidal=2;
        Sinusoidal=rand(N,dim);
        for i=1:N
            for j=2:dim
                Sinusoidal(i,j)=sinusoidal*Sinusoidal(i,j-1).^2*(sin(pi*Sinusoidal(i,j-1)));
            end
        end
        result = Sinusoidal;
        
    case 7
        %Sine ӳ��
        sine=2;
        Sine=rand(N,dim);
        for i=1:N
            for j=2:dim
                Sine(i,j)=(4/sine)*sin(pi*Sine(i,j-1));
            end
        end
        result = Sine;
        
        
    case 8
        %         ICMIC ӳ�䣨�����۵���������ӳ�䣩
        icmic=2;
        ICMIC=rand(N,dim);
        for i=1:N
            for j=2:dim
                ICMIC(i,j)=sin(icmic/ICMIC(i,j-1));
            end
        end
        result = ICMIC;
        
        
    case 9
        % Circle ӳ��
        a = 0.5; b=0.6;
        Circle=rand(N,dim);
        for i=1:N
            for j=2:dim
                Circle(i,j)=mod(Circle(i,j-1)+a-b/(2*pi)*sin(2*pi*Circle(i,j-1)),1);
            end
        end
        result = Circle;
    case 10
        %Bernoulli ӳ��
        lammda = 0.4;
        Bernoulli=rand(N,dim);
        for i=1:N
            for j=2:dim
                if Bernoulli(i,j-1) <  1-lammda
                    Bernoulli(i,j)= Bernoulli(i,j-1)/(1-lammda);
                else
                    Bernoulli(i,j)= (Bernoulli(i,j-1)-1+lammda)/lammda;
                end
            end
        end
        result = Bernoulli;
        
        
        
    case 11    %û���κ�ӳ�䣬�������
        result =rand(N,dim);

    case 12 %Fuch����ӳ�����
        fuch =rand(N,dim);
        for i=1:N
            for j=2:dim
                fuch(i,j)=abs(cos(1./fuch(i,j-1).^2));
            end
        end
        result = fuch;
 
        
        
end
 %%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn
 %%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn%%%%%%%%%%%%%%���������ѧ-���л�-2023.01.01-yangzhonghua@stu.xjtu.edu.cn

